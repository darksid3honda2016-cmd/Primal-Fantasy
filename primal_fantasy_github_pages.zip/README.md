# Primal Fantasy — Browser Prototype

A small static browser-game prototype.

## Publish free with GitHub Pages

1. Sign in to [GitHub](https://github.com/) or create a free account.
2. Create a **new public repository** named `primal-fantasy`.
3. Upload `index.html` from this folder to the repository's root (top level), then commit the change.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. GitHub Pages will show the published URL, usually:
   `https://YOUR-USERNAME.github.io/primal-fantasy/`

## Notes

- The game is a front-end prototype, not a complete online MMORPG.
- Save Game uses browser local storage on the same device/browser.
- There is no multiplayer server, account system, cloud save, or database yet.
- To update the game, upload/replace `index.html` and commit the change. Pages will redeploy automatically.
